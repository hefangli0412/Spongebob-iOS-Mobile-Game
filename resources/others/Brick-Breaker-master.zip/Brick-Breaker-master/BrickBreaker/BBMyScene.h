//
//  BBMyScene.h
//  BrickBreaker
//

//  Copyright (c) 2014 J Hastwell. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface BBMyScene : SKScene <SKPhysicsContactDelegate>

@end
